<?php
function getBD(){
$bdd = new PDO('mysql:host=localhost;dbname=MovieShop;charset=utf8','root','');
return $bdd;
}
?>