<?php
session_start();

if (!isset($_SESSION['token'])) {
	$_SESSION['token'] = bin2hex(random_bytes(32));
}

$token = $_SESSION['token'];
?>
<!DOCTYPE html>
<html class="article" lang="fr">
<head>
	<meta charset="UTF-8">
	<link href="../styles/style.css" rel="stylesheet" type="text/css" />
	<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  	<script src="../chats/chat.js"></script>
	<title>page 1</title>
</head>

<body>

<h1>Articles</h1>

<?php
require '../bd.php';


if (isset($_GET['id_art']) && is_numeric($_GET['id_art'])) {
    $id_art = intval($_GET['id_art']);
	$bdd = getBD();
	$req = $bdd->prepare('select * from articles where id_art = :id_art');
	$req->bindParam(':id_art', $id_art, PDO::PARAM_INT);
	$req->execute();

	$article = $req->fetch();
	if($article) {
		echo '<h2>' . htmlspecialchars($article['nom']) . '</h2>
		<img src="' . htmlspecialchars($article['url_photo']) . '" alt="affiche du film">
		<p>'.htmlspecialchars($article['description']).'</p>';
	}
	else {
		echo 'warning !';
	}

	$req ->closeCursor();
}
else {
	echo "l'id_art n'existe pas";
}
?>


<form method= "post" action="../panier/ajouter.php" autocomplete="on">
	
	<?php
		if(isset($_SESSION['client']) && isset($_GET['id_art']) && is_numeric($_GET['id_art'])){
			echo "<p> <input type='hidden' name='id_art' value='" . $id_art . "' /> </p>";
			echo "<p> Nombre exemplaire : <input type='number' name='exemplaire' value='' /> </p>";
			echo "<p> <input type='submit' value='Ajouter à votre panier' /> </p>";
			echo "<p> <input type='hidden' name='csrf_token' value=' ". $token ."' /> </p>";
		}    
    ?>
</form>

<?php
if (isset($_SESSION['client'])){
	//chats
	echo '<div id="chat-form-container">';
	echo '<div id="chat-messages-container"></div>';
	echo '<form method="post" id="chat-form">';
	echo '<label for="messages">Message :</label>';
	echo '<input type="text" id="messages" name="messages" required>';
	echo '<input type="hidden" id="csrf_token" name="csrf_token" value="'.$token.'">';
	echo '<button type="submit">Envoyer</button>';
	echo '</form>';
	echo '</div>';
}
?>

<p><a href="../index.php">Retour</a></p>
</body>
</html>