<?php
session_start();
require "../bd.php";
$bdd = getBD();

//supprimer les messages de plus de 10 min de la base de donnée
$reqDeleteQuery = 'DELETE FROM chats WHERE TIMESTAMPDIFF(SECOND, timestamp, NOW()) > 600';
$reqDelete = $bdd->prepare($reqDeleteQuery);
$reqDelete->execute();

if (isset($_SESSION['client'])) {

    // Récupération des messages
    $req = $bdd->prepare("SELECT * FROM chats, clients WHERE chats.id_client = clients.id_client");
    $req->execute();
    $recentMessages = [];
    
    while ($message = $req->fetch(PDO::FETCH_ASSOC)) {
        $recentMessages[] = [
            'prenom' => $message['prenom'],
            'message' => htmlspecialchars($message['message'])
        ];
    }
    echo json_encode(['res' => true, 'message' => 'Récupération des messages réussie', 'data' => $recentMessages]);   
} 
else {
    echo json_encode(['res' => false, 'message' => 'Erreur : Vous n\'êtes pas connecté']);
}
?>
