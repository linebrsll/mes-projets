$(document).ready(function () {
    console.log("Document prêt");
  
    loadMessages();
    setInterval(function () {
      loadMessages();
    }, 1000);
  
      $("#chat-form").submit(function (event) {
  
        console.log("Formulaire soumis");
        event.preventDefault();
        var messages = $("#messages").val();
        var token = $("#csrf_token").val(); 
  
        $.ajax({
          url: '/BRANSOLLE/chats/send_message.php',
          method: 'POST',
          data: {
            messages: messages,
            csrf_token : token,
          },
          success: function (result) {
            result = JSON.parse(result);
            if (result.res) {
              console.log("success : ", result);
              $("#messages").val('');
              loadMessages();
            } 
            else {
              console.log("echec : ", result);
            }
          },
          error: function (xhr, status, error) {
            console.error('Erreur lors de l\'ajout du message');
          }
        });
  
      });
  
      function loadMessages(){
        console.log("fonction loadMessages s'exécute");
        $.ajax({
          url : '/BRANSOLLE/chats/get_messages.php',
          method : 'POST',
          success: function(result){
            result = JSON.parse(result);
            if(result.res){
              console.log("succès : ", result);
              console.log("data : ", result.data);
  
              var messagesContainer = $("#chat-messages-container");
              messagesContainer.empty();
              result.data.forEach(function (message) {
                messagesContainer.append('<div class="message">' + message.prenom + ' dit '+ "'" + message.message + "'" +  '</div>');
              });
            }
            else {
              console.log("échec : ", result);
            }
          },
          error: function (xhr, status, error){
            console.error('Erreur lors de la récupération des messages');
          }
        });
      }

    });